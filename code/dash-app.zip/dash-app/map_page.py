# imports
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import dash_core_components as dcc
import dash_bootstrap_components as dbc
import dash_html_components as html
from dash.dependencies import Input, Output
# data set imports from the app file
from app import app, df as df

# get hotel names for list
hotels = df['Hotel_Name'].unique()

# get all available hotels for the hotel selection drop down menu
hotel_options = []
track = 0
hotel_options.append({'label': 'All', 'value': 'All'})
for hotel in hotels:
    hotel_options.append({'label': hotel, 'value': hotel})

# layout, the html aspect of this page
map_layout = dbc.Container(
    children=[
        dbc.Col(
            children=[
                dbc.Card(
                    dbc.CardBody(
                        style={'min-height': '400px'},
                        children=[
                            dbc.Row(
                                children=[
                                    dbc.Col(
                                        children=[
                                            # data type selection drop down
                                            dcc.Dropdown(id='select_map',
                                                         options=[{'label': 'By Reviewer', 'value': 0},
                                                                  {'label': 'By Hotel', 'value': 1}],
                                                         value=0,
                                                         clearable=False),
                                        ], className='col-3'
                                    ),
                                    dbc.Col(
                                        children=[
                                            # hotel selection drop down
                                            dcc.Dropdown(id='select_hotel',
                                                         options=hotel_options,
                                                         value=hotel_options[0]['value'],
                                                         clearable=False),
                                        ], className='col-3'
                                    ),
                                    dbc.Col(
                                        children=[
                                            # month selection drop down
                                            dcc.Dropdown(id='select_month',
                                                         value=12,
                                                         options=[{'label': 'January', 'value': 1},
                                                                  {'label': 'February', 'value': 2},
                                                                  {'label': 'March', 'value': 3},
                                                                  {'label': 'April', 'value': 4},
                                                                  {'label': 'May', 'value': 5},
                                                                  {'label': 'June', 'value': 6},
                                                                  {'label': 'July', 'value': 7},
                                                                  {'label': 'August', 'value': 8},
                                                                  {'label': 'September', 'value': 9},
                                                                  {'label': 'October', 'value': 10},
                                                                  {'label': 'November', 'value': 11},
                                                                  {'label': 'December', 'value': 12}],
                                                         clearable=False)
                                        ], className='col-3'
                                    ),
                                    dbc.Col(
                                        children=[
                                            # year selection drop down
                                            dcc.Dropdown(id='select_year',
                                                         value=2015,
                                                         options=[{'label': '2015', 'value': 2015},
                                                                  {'label': '2016', 'value': 2016},
                                                                  {'label': '2017', 'value': 2017}],
                                                         clearable=False)
                                        ], className='col-3'
                                    )
                                ]
                            ),
                            dbc.Row(
                                children=[
                                    dbc.Col(
                                        children=[
                                            # map figure
                                            dcc.Graph(id='review_map', figure={}),
                                        ]
                                    )
                                ], className='col-12'
                            ),
                        ],
                    )
                ),
            ],
        )
    ],
    # general page styling
    className='pt-2 pl-4 pr-4',
    style={'min-height': '100vh', 'background-color': 'rgba(242, 242, 242,1)'},
    fluid=True
)


# call back functions
# when actions are made on the webpage, these functions are called
@app.callback(Output(component_id='review_map', component_property='figure'),
              [Input(component_id='select_map', component_property='value'),
               Input(component_id='select_hotel', component_property='value'),
               Input(component_id='select_month', component_property='value'),
               Input(component_id='select_year', component_property='value')])
# display the map depending on selected data
def display_map(map_type, map_hotel, map_month, map_year):
    # select data based on hotel, month, and year selection
    if map_hotel != 'All':
        map_data = df[df['Hotel_Name'] == map_hotel]
        map_data = map_data[map_data['Review_Date'].str.match(str(map_month) + '/' + r'[\d]{1,2}' + '/' + str(map_year))]
    else:
        map_data = df[df['Review_Date'].str.match(str(map_month) + '/' + r'[\d]{1,2}' + '/' + str(map_year))]

    # sorting by reviewer visualization
    if map_type == 0:
        nationalities = map_data['Reviewer_Nationality'].unique()

        average_scores = []
        counts = []
        for nation in nationalities:
            average_scores.append(map_data[map_data['Reviewer_Nationality'] == nation]['Reviewer_Score'].mean())
            counts.append(map_data[map_data['Reviewer_Nationality'] == nation]['Reviewer_Score'].count())

        processed_map = pd.DataFrame()
        processed_map['Nationality'] = nationalities
        processed_map['Average Score'] = average_scores
        processed_map = processed_map.round({'Average Score': 2})
        processed_map['Number of Reviews'] = counts

        fig = px.choropleth(processed_map,
                            locations='Nationality',
                            locationmode='country names',
                            color='Average Score',
                            hover_data=['Nationality', 'Average Score', 'Number of Reviews'],
                            color_continuous_scale='PuRd',
                            range_color=[0, 10],
                            projection="natural earth")

        fig.update_layout(
            title='Data by Reviewer<br>' +
                  'Hotel Selected: ' + str(map_hotel) + '<br>' +
                  'Date Selected: ' + str(map_month) + '/' +
                  str(map_year) + '<br>' + 'Hover for Reviewer Data',
        )
    # sorting by hotel visualization
    else:
        map_data['text'] = 'Hotel Name: ' + map_data['Hotel_Name'] + ', Average Review Score: ' + map_data['Average_Score'].astype(str)

        fig = go.Figure(data=go.Scattergeo(
            lat=map_data['lat'],
            lon=map_data['lng'],
            text=map_data['text'],
            mode='markers',
            marker_color=map_data['Average_Score'],
            marker=dict(
                colorscale='PuRd',
                cmin=0,
                color=df['Average_Score'],
                cmax=df['Average_Score'].max(),
                colorbar_title="Average Review Score"
            )))

        fig.update_layout(
            title='Data by Hotel<br>Date Selected: ' + str(map_month) + '/'
                  + str(map_year) + '<br>Hover for Hotel Name',
            geo_scope='europe',
        )

    return fig


@app.callback([Output(component_id='select_month', component_property='options'),
               Output(component_id='select_month', component_property='value')],
              Input(component_id='select_year', component_property='value'))
# 2017 does not have data for the last four months,
# this function makes those months not selectable when 2017 is the selected year
def filter_months(year):
    if year == 2017:
        value = 12
        options = [{'label': 'January', 'value': 1},
                   {'label': 'February', 'value': 2},
                   {'label': 'March', 'value': 3},
                   {'label': 'April', 'value': 4},
                   {'label': 'May', 'value': 5},
                   {'label': 'June', 'value': 6},
                   {'label': 'July', 'value': 7},
                   {'label': 'August', 'value': 8}]
    else:
        value = 12
        options = [{'label': 'January', 'value': 1},
                   {'label': 'February', 'value': 2},
                   {'label': 'March', 'value': 3},
                   {'label': 'April', 'value': 4},
                   {'label': 'May', 'value': 5},
                   {'label': 'June', 'value': 6},
                   {'label': 'July', 'value': 7},
                   {'label': 'August', 'value': 8},
                   {'label': 'September', 'value': 9},
                   {'label': 'October', 'value': 10},
                   {'label': 'November', 'value': 11},
                   {'label': 'December', 'value': 12}]
    return options, value
