import dash
import dash_bootstrap_components as dbc
import pandas as pd

# the data set is read once for the whole app hear
# other pages will then import the data set from here, instead of having to read it all again
df = pd.read_csv('Hotel_Reviews.csv')

# set up local server and app, along with boostrap styling options
external_stylesheets = [dbc.themes.BOOTSTRAP]
app = dash.Dash(__name__, suppress_callback_exceptions=True, external_stylesheets=external_stylesheets)
server = app.server
