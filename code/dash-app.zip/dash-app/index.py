import dash_core_components as dcc
import dash_bootstrap_components as dbc
import dash_html_components as html
from dash.dependencies import Input, Output

# Databenders Dash app
from app import app

from map_page import map_layout

# general navigation layout
# can be thought of as skeleton code for the whole web application
# this allows for the web application to be added to throughout future work
app.layout = html.Div(
    children=[
        dbc.NavbarSimple(
            children=[
                dbc.NavItem(dbc.NavLink("Map", href="/map")),
            ],
            brand='Hotel Review Data Set',
            dark=True,
            className="navbar navbar-dark bg-dark"
        ),
        html.Div(
            children=[
                dcc.Location(id='url', refresh=False),
                html.Div(id='page-content'),
            ],
            style={'width': '100%'}
        )
    ]
)


@app.callback(
    Output('page-content', 'children'),
    Input('url', 'pathname'))
# display the web page chosen on the nav bar, currently you can only view map data
# future work may add to this navigation bar
def display_page(pathname):
    if pathname == '/map' or pathname == '/':
        return map_layout
    else:
        return dbc.Container('Error 404: Page Not Found!', className='display-4 mt-5')


# run the app!
if __name__ == "__main__":
    app.run_server(debug=True)
